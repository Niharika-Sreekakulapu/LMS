package com.infy.lms.enums;

public enum Role {
    ADMIN,
    LIBRARIAN,
    STUDENT
}
