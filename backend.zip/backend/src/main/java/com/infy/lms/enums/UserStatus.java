package com.infy.lms.enums;

public enum UserStatus {
    PENDING,
    APPROVED,
    REJECTED
}
